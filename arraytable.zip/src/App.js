import "./styles.css";
import DisplayData from "./DisplayData";

function App() {
  return (
    <div>
      <DisplayData />
    </div>
  );
}

export default App;
