import "./styles.css";
import ViewItems from "./ViewItems";

export default function App() {
  return (
    <div className="App">
      <ViewItems />
    </div>
  );
}
