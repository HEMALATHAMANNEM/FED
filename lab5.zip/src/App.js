//import "./App.css";
import MyCart from "./MyCart";
function App() {
  return (
    <div>
      <MyCart />
    </div>
  );
}
export default App;
