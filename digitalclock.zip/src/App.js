import "./styles.css";
import DigitalClock from "./DigitalClock";
function App() {
  return (
    <div style={{ width: "90%", margin: "0 auto" }}>
      <DigitalClock />
    </div>
  );
}

export default App;
