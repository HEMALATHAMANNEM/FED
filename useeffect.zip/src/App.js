import "./styles.css";
import DigiClock from "./DigiClock";
export default function App() {
  return (
    <div className="App">
      <DigiClock />
    </div>
  );
}
