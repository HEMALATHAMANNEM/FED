import "./styles.css";
import TextColorDemo from "./TextColorDemo";
import ChangeColors from "./ChangeColors";
function App() {
  return (
    <div style={{ width: "90%", margin: "0 auto" }}>
      <ChangeColors />
      <TextColorDemo />
    </div>
  );
}

export default App;
