import "./styles.css";
import CricScore from "./CricScore";
function App() {
  return (
    <div>
      <CricScore />
    </div>
  );
}
export default App;
